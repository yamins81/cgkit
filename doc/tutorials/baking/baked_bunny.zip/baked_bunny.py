# The Stanford Bunny on a parquet floor using baked textures

Globals(
    up = (0,1,0),
    background = (0.2,0.2,0.2)
)

TargetCamera(
    pos = (-50, 30, 50),
    target = (0,0,0),
    fov = 30
)

# Load the bunny scene and assign the new materials
load("bunnyplane.obj")
bunny = worldObject("Bunny")
floor = worldObject("Floor")

mat_bunny = GLMaterial(
    diffuse = (0.9,0.9,1),
    texture = GLTexture("bunny_ao.jpg",
                        mode = GL_DECAL,
                        transform = mat4().scaling(vec3(1,-1,1)))
)
bunny.setMaterial(mat_bunny)

mat_floor = GLMaterial(
    diffuse = (1,1,1),
    texture = GLTexture("floor_ao.jpg",
                        mode = GL_DECAL,
                        transform = mat4().scaling(vec3(1,-1,1)))
)
floor.setMaterial(mat_floor)

