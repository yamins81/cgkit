# Bake a texture map

Globals(
    bake = True,
    resolution = (512, 512),
    pixelsamples = (2,2),
    output = "ao_map.tif",
    displaymode = "rgba"
)

# Load the model
load("model.obj")

# Obtain a reference to the model
model = worldObject("Model")

# Set the bake material
mat = RMMaterial(
    surface = RMShader(
        "bake_ao.sl",
        samples = 1000,
    )
)
model.setMaterial(mat)

# Add a ground plane to block "light" coming from below
Plane(
    lx = 5,
    ly = 5,
    rot = mat3().fromEulerXYZ(radians(90),0,0)
)
