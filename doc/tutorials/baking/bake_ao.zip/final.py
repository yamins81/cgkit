# Use the previously rendered texture map

Globals(
    up = (0,1,0)
)

load("model.obj")
model = worldObject("Model")

mat = GLMaterial(
    diffuse = (0,1,0),
    texture = GLTexture(
        "ao_map.png",
        mode = GL_DECAL,
        transform = mat4().scaling(vec3(1,-1,1))
    )
)
model.setMaterial(mat)
